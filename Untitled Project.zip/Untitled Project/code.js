var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var BALL1 = createSprite(255, 380, 25, 25);
var BALL2 = createSprite(215, 330, 25, 25);
var BALL3 = createSprite(175, 280, 25, 25);
var BALL4 = createSprite(125, 330, 25, 25);
var BALL5 = createSprite(75, 380, 25, 25);
BALL1.velocityX = 2;
BALL1.velocityY = 2;
BALL2.velocityX = -2;
BALL2.velocityY = -2;
BALL3.velocityX = 2;
BALL3.velocityY = 2;
BALL4.velocityX = -2;
BALL4.velocityY = -2;
BALL5.velocityX = 2;
BALL5.velocityY = 2;
function draw() {
  background("YELLOW");
  createEdgeSprites();
  BALL1.bounceOff(edges);
  BALL2.bounceOff(edges);
  BALL3.bounceOff(edges);
  BALL4.bounceOff(edges);
  BALL5.bounceOff(edges);
  BALL1.bounce(BALL2);
  BALL2.bounce(BALL3);
  BALL3.bounce(BALL4);
  BALL4.bounce(BALL5);
  BALL5.bounce(BALL1);
  BALL3.shapeColor = "WHITE";
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
